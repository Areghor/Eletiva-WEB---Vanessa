<!DOCTYPE html>
<html>
<head>
    <title>Bem-vindo</title>
</head>
<body>
    <h2>Bem-vindo ao Finanças PRO</h2>
    <p>Olá, {{ $username }}!</p>
    <p>Aqui estão as suas credenciais de acesso:</p>
    <p><strong>Nome de Usuário:</strong> {{ $username }}</p>
    <p><strong>Senha:</strong> {{ $password }}</p>
    <p>Você pode usar essas credenciais para acessar o Finanças PRO.</p>
    <p>Obrigado por se juntar a nós e bons estudos!</p>
</body>
</html>
